Leaflet.zoomdisplay
===================

Leaflet.zoomdisplay is a plugin that displays the current zoom level of the map.

[See a demo](http://azavea.github.com/Leaflet.zoomdisplay/)

## Usage

  1. Add a `<script>` tag to your map page referencing the javascript.
  2. Add a `<link>` tag to your map page referencing the stylesheet
  3. There is no step three.